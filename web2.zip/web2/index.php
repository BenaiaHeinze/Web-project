<?php
$accio = $_GET['accio'] ?? NULL;

switch ($accio) {
    case 'registre':
        include __DIR__.'/resources/resource_registre.php';
        break;
    case 'login':
        include __DIR__.'/resources/resources_login.php';
        break;
    case 'cabas':
        include __DIR__.'/resources/resource_cabas.php';
        break;
    case 'categoria':
        include __DIR__.'/resources/resources_categoria.php';
        break;
    case 'producte':
        include __DIR__.'/resources/resources_producte.php';
        break;
    default:
        include __DIR__.'/resources/resource_menu_inicial.php';
        break;
}
?>
