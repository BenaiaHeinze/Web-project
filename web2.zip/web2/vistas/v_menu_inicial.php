<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Librería Online</title>
    <link rel="stylesheet" href="./css/index.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="/../js/funcions.js"></script>
    <script src="/../js/search.js"></script>
</head>
<body>
    <?php include __DIR__ . '/v_header.php'; ?>

    <main>
        <?php include __DIR__ . '/../controlador/c_categories.php'; ?>
        <div id="products" style="display: none;"></div>
        <div id="book-detail" style="display: none;"></div>
    </main>


    <?php include __DIR__ . '/v_footer.php'; ?>

</body>
</html>