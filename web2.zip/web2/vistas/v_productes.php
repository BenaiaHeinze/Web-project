<div id="products">
    <?php foreach ($llibres as $product): ?>
        <div class="book-link" data-id="<?php echo $product['id']; ?>">
            <img src="<?php echo $product['path_img']; ?>" alt="<?php echo $product['nom']; ?>" />
            <div><?php echo $product['nom']; ?></div>
            <div>Autor: <?php echo $product['autor']; ?></div>
        </div>
    <?php endforeach; ?>
</div>

