<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Mis Compras</title>
    <link rel="stylesheet" href="../css/comandes.css">
</head>
<body>
    <?php require_once __DIR__. '/../controlador/c_header.php'; ?>

    <main>
        <h2>Mis Compras</h2>

        <?php if (!empty($orders)): ?>
            <table>
                <thead>
                    <tr>
                        <th>ID de la Comanda</th>
                        <th>Data</th>
                        <th>Número d'Elements</th>
                        <th>Import Total (€)</th>
                        <th>Detalls</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($orders as $order): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($order['id']); ?></td>
                            <td><?php echo htmlspecialchars($order['data_creació']); ?></td>
                            <td><?php echo htmlspecialchars($order['num_elements']); ?></td>
                            <td><?php echo number_format($order['import_total'], 2); ?></td>
                            <td>
                                <a href="/controlador/c_comandes_detalls.php?order_id=<?php echo $order['id']; ?>">
                                    Veure Detalls
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>No tens comandes realitzades.</p>
        <?php endif; ?>
    </main>

    <?php require_once __DIR__. '/../controlador/c_footer.php'; ?>
</body>
</html>
