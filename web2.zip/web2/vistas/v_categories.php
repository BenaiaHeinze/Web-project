<div id="categories">
    <?php foreach ($categories as $category): ?>
        <div class="category-link" data-id="<?php echo htmlentities($category['id'], ENT_QUOTES | ENT_HTML5, 'UTF-8'); ?>">
            <img src="<?php echo htmlentities($category['path_img'], ENT_QUOTES | ENT_HTML5, 'UTF-8'); ?>">
            <span><?php echo htmlentities($category['nom'], ENT_QUOTES | ENT_HTML5, 'UTF-8'); ?></span>
        </div>
    <?php endforeach; ?>
</div>
