<main>
    <h2>Registro de Usuario</h2>

    <?php if (isset($_GET['error'])): ?>
        <div class="error-message">
            <?php 
            switch ($_GET['error']) {
                case '1':
                    echo "Por favor, rellena todos los campos.";
                    break;
                case '2':
                    echo "Datos inválidos. Revisa el formulario.";
                    break;
                case '3':
                    echo "Error al registrar al usuario. Inténtalo de nuevo.";
                    break;
                default:
                    echo "Ha ocurrido un error desconocido.";
            }
            ?>
        </div>
    <?php endif; ?>
    
    <form action="../controlador/c_registre.php" method="POST" onsubmit="return validateForm()">
        <label for="username">Nombre y apellidos:</label>
        <input type="text" id="username" name="username" required>
        
        <label for="email">Correo electrónico:</label>
        <input type="email" id="email" name="email" required>
        
        <label for="password">Contraseña:</label>
        <input type="password" id="password" name="password" required>

        <label for="address">Dirección:</label>
        <input type="text" id="address" name="address" maxlength="30" required>
        
        <label for="city">Ciudad:</label>
        <input type="text" id="city" name="city" maxlength="30" required>
        
        <label for="postalCode">Código Postal:</label>
        <input type="text" id="postalCode" name="postalCode" required>

        <input type="submit" value="Registrar">
    </form>
</main>

