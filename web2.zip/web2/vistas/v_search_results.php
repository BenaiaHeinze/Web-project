<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Resultados de la Búsqueda</title>
    <link rel="stylesheet" href="/css/search.css">
</head>
<body>
    <?php include_once __DIR__ . '/../controlador/c_header.php'; ?> <!-- Header fijo -->

    <main>
        <h2>Resultados de la Búsqueda</h2>
        <div id="search-results" class="search-results">
            <?php if (!empty($productos)): ?>
                <?php foreach ($productos as $producto): ?>
                    <div class="search-item">
                        <img src="<?php echo htmlspecialchars($producto['path_img']); ?>" alt="<?php echo htmlspecialchars($producto['nom']); ?>" />
                        <div>
                            <strong><?php echo htmlspecialchars($producto['nom']); ?></strong>
                            <p><?php echo htmlspecialchars($producto['descripcio']); ?></p>
                            <span>€<?php echo number_format($producto['preu'], 2); ?></span>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <p>No se encontraron productos que coincidan con tu búsqueda.</p>
            <?php endif; ?>
        </div>
    </main>

    <?php include_once __DIR__ . '/../controlador/c_footer.php'; ?> <!-- Footer -->
</body>
</html>
