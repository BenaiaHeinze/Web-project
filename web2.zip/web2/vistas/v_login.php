<!-- /vistas/login.php -->
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Iniciar Sesión</title>
    <link rel="stylesheet" href="../css/formulari.css">
    <script src="/../js/funcions.js"></script>
</head>
<body>
    <?php include 'v_header.php'; ?>

    <main>
        <h2>Iniciar Sesión</h2>

        <?php if (isset($_GET['accio']) && $_GET['accio'] === 'error'): ?>
            <p style="color:red;">Error: Credenciales incorrectas. Intenta de nuevo.</p>
        <?php endif; ?>

        <form action="../controlador/c_login.php" method="POST">
            <label for="email">Correo Electrónico:</label>
            <input type="email" id="email" name="email" required>

            <label for="password">Contraseña:</label>
            <input type="password" id="password" name="password" required>

            <input type="submit" value="Iniciar Sesión">
        </form>
    </main>

    <?php include 'v_footer.php'; ?>
</body>
</html>
