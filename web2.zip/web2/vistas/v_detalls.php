
<div><strong><?php echo $producte['nom']; ?></strong></div>
<img src="<?php echo $producte['path_img']; ?>" alt="<?php echo $producte['nom']; ?>" />
<div><strong>Precio: </strong><?php echo $producte['preu']; ?>€</div>
<div><strong>ISBN: </strong><?php echo $producte['isbn']; ?></div>
<div><strong>Descripción: </strong><?php echo $producte['descripcio']; ?></div>

<!-- Add to Cart Section -->
<div>
    <label for="cantidad">Cantidad:</label>
    <input type="number" id="cantidad" value="1" min="1" max="100">
    <button id="add-to-cart" data-id="<?php echo $id_producte; ?>">Añadir al carrito</button>
</div>
<div id="cart-response" style="margin-top: 10px;"></div>

