<?php
session_start();
require_once __DIR__ . '/../model/m_cabas.php';

$cart = $_SESSION['cabas'] ?? [];
//$totalPrice = 0;
?>

    <main>
        <h2>Carrito</h2>
        <?php if (!empty($products)): ?>
            <div class="cart-container">
                <?php foreach ($products as $product): ?>
                    <div class="cart-item" data-id="<?php echo $product['id']; ?>">
                        <div class="cart-item-image">
                            <img src="<?php echo htmlspecialchars($product['path_img']); ?>" alt="<?php echo htmlspecialchars($product['nom']); ?>">
                        </div>
                        <div class="cart-item-details">
                            <h3><?php echo htmlspecialchars($product['nom']); ?></h3>
                            <label for="quantity-<?php echo $product['id']; ?>">Quantitat:</label>
                            <input type="number" id="quantity-<?php echo $product['id']; ?>" class="update-quantity" data-id="<?php echo $product['id']; ?>" value="<?php echo $product['quantitat']; ?>" min="1">
                            <p>Preu unitari: €<?php echo number_format($product['preu'], 2); ?></p>
                            <p>Import Total: €<span class="item-total"><?php echo number_format($product['itemTotal'], 2); ?></span></p>
                            <button class="remove-item" data-id="<?php echo $product['id']; ?>">Eliminar</button>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <div class="empty-cart">
                <img src="/img/empty-cart.png" alt="Carrito vacío" class="empty-cart-image">
                <p class="empty-cart-message">¡Tu carrito está vacío! ¿Por qué no exploras nuestros <a href="/index.php">productos</a>?</p>
            </div>
        <?php endif; ?>

        <!-- El total del carrito es mou aquí avall -->
        <?php if (!empty($products)): ?>
            <div class="cart-summary">
                <p class="cart-total"><strong>Total del Carrito:</strong> €<span id="total-price"><?php echo number_format($totalPrice, 2); ?></span></p>
                <button id="checkout-button" class="btn">Finalitzar Compra</button>
                <button id="clear-cart-button" class="btn">Vaciar el carrito</button>
            </div>
        <?php endif; ?>
    </main>



