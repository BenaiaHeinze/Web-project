<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Buscador</title>
    <link rel="stylesheet" href="/css/search.css">
</head>
<body>
    <header>
        <h1>Buscador de Productos</h1>
    </header>
    <main>
        <input type="text" id="search-bar" placeholder="Buscar productos..." />
        <div id="search-results" class="search-results"></div>
    </main>
    <script src="/js/search.js"></script>
</body>
</html>
