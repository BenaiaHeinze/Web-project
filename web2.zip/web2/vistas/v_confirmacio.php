<?php
session_start();
require_once __DIR__ . '/../model/m_checkout.php';

$orderId = $_GET['order_id'] ?? null;
if (!$orderId) {
    echo "No s'ha trobat la comanda.";
    exit;
}

$order = getOrderDetails($orderId);
$lineItems = getOrderLineItems($orderId);

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Confirmació de Compra</title>
    <link rel="stylesheet" href="../css/confirmacio.css">
</head>
<body>
    <?php include __DIR__ . '/v_header.php'; ?>

    <main>
        <h2>Confirmació de la Comanda</h2>
        <p><strong>Comanda ID:</strong> <?php echo htmlspecialchars($orderId); ?></p>
        <p><strong>Data:</strong> <?php echo htmlspecialchars($order['data_creació']); ?></p>
        <p><strong>Import Total:</strong> €<?php echo number_format($order['import_total'], 2); ?></p>

        <h3>Detalls de la Comanda</h3>
        <ul>
            <?php foreach ($lineItems as $item): ?>
                <li>
                    <strong><?php echo htmlspecialchars($item['nom']); ?></strong>
                    Quantitat: <?php echo htmlspecialchars($item['num_producte']); ?> |
                    Preu: €<?php echo number_format($item['preu_total'], 2); ?>
                </li>
            <?php endforeach; ?>
        </ul>
    </main>

    <?php include 'v_footer.php'; ?>
</body>
</html>
