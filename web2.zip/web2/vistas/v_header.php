<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>
<link rel="stylesheet" href="../css/header.css">

<!-- views/header.php -->
<header>
    <h1>Librería Online</h1>
</header>

<!-- views/nav.php -->
<nav>
    <ul>
        <form action="/controlador/c_search.php" method="GET">
            <input type="text" id="search-bar" name="query" placeholder="Buscar productos..." required>
            <button type="submit">Buscar</button>
        </form>

        <div class="center-nav">
            <li><a href="/../index.php">Inicio</a></li>
        </div>
        <li class="account">
            <a href="#" class="account-button">
                <?php
                // Determine profile image to display
                $profileImg = isset($_SESSION['user']['path_img']) && !empty($_SESSION['user']['path_img']) 
                    ? "/../img/users/" . $_SESSION['user']['path_img']  // Use the existing path if set
                    : "/../img/users/profile_icon.png";    // Default profile image path
                ?>
                <img src="<?php echo htmlspecialchars($profileImg); ?>" alt="User photo" width="30px" height="30px">
                Cuenta
            </a>

            <ul class="dropdown">
                <?php if (isset($_SESSION['user'])): ?>
                    <li><a href="/controlador/c_perfil.php">Mi cuenta</a></li>
                    <li><a href="/controlador/c_comandes.php">Mis compras</a></li>
                    <li><a href="/controlador/c_logout.php">Cerrar sesión</a></li>
                <?php else: ?>
                    <li><a href="/index.php?accio=login">Iniciar sesión</a></li>
                    <li><a href="/index.php?accio=registre">Registro</a></li>
                <?php endif; ?>
            </ul>
        </li>
        <li class="shopping-cart">
            <a href="/index.php?accio=cabas">🛒</a>
        </li>
    </ul>
</nav>

<?php
if (isset($_SESSION['cabas']) && !empty($_SESSION['cabas'])) {
    require_once __DIR__ . '/../model/m_cabas.php';
    $cartSummary = getCartSummary();
    $totalItems = $cartSummary['totalItems'];
    $totalPrice = $cartSummary['totalPrice'];
} else {
    $totalItems = 0;
    $totalPrice = 0.00;
}
?>
<div id="cart-summary" style="margin: 10px; border: 1px solid #ccc; padding: 10px; width: fit-content;">
    <strong>Carrito:</strong>
    <div>
        <span id="cart-total-items"><?php echo $totalItems; ?></span> productos - 
        €<span id="cart-total-price"><?php echo number_format($totalPrice, 2); ?></span>
    </div>
</div>
