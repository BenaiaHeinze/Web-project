<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Detalls de la Comanda</title>
    <link rel="stylesheet" href="../css/comandes.css">
</head>
<body>
    <?php include 'v_header.php'; ?>

    <main>
        <h2>Detalls de la Comanda</h2>
        <p><strong>Comanda ID:</strong> <?php echo htmlspecialchars($order['id']); ?></p>
        <p><strong>Data:</strong> <?php echo htmlspecialchars($order['data_creació']); ?></p>
        <p><strong>Import Total:</strong> €<?php echo number_format($order['import_total'], 2); ?></p>

        <h3>Línies de Comanda</h3>
        <?php if (!empty($lineItems)): ?>
            <ul>
                <?php foreach ($lineItems as $item): ?>
                    <li>
                        <strong><?php echo htmlspecialchars($item['nom']); ?></strong> -
                        Quantitat: <?php echo htmlspecialchars($item['num_producte']); ?> -
                        Preu Total: €<?php echo number_format($item['preu_total'], 2); ?>
                    </li>
                <?php endforeach; ?>
            </ul>
        <?php else: ?>
            <p>No hi ha línies de comanda per aquesta comanda.</p>
        <?php endif; ?>
    </main>

    <?php include 'v_footer.php'; ?>
</body>
</html>
