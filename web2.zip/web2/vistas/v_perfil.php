<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Edit Profile</title>
    <link rel="stylesheet" href="../css/perfil.css">
    <link rel="stylesheet" href="../css/index.css">

</head>
<body>
    <?php include 'v_header.php'; ?>

    <main>
        <h2>Edita el teu Perfil</h2>

        <?php if (isset($_GET['success'])): ?>
            <p class="success-message">Perfil actualitzat correctament.</p>
        <?php elseif (isset($_GET['error'])): ?>
            <p class="error-message">
                <?php
                switch ($_GET['error']) {
                    case 'invalid_file':
                        echo "Tipus de fitxer no vàlid. Només JPG, PNG i GIF estan permesos.";
                        break;
                    case 'upload_failed':
                        echo "No s'ha pogut pujar la imatge. Torna-ho a intentar.";
                        break;
                    case 'password_mismatch':
                        echo "Les contrasenyes no coincideixen.";
                        break;
                    case 'incorrect_password':
                        echo "La contrasenya actual és incorrecta.";
                        break;
                    case 'password_update_failed':
                        echo "Error en actualitzar la contrasenya. Torna-ho a intentar.";
                        break;
                    case 'update_failed':
                        echo "Error en actualitzar el perfil. Torna-ho a intentar.";
                        break;
                    default:
                        echo "Ha ocorregut un error inesperat.";
                }
                ?>
            </p>
        <?php endif; ?>

        <form action="/controlador/c_perfil.php" method="POST" enctype="multipart/form-data">
            <label for="username">Nom:</label>
            <input type="text" id="username" name="username" value="<?php echo htmlspecialchars($user['nom']); ?>" required>

            <label for="email">Email:</label>
            <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($user['email']); ?>" required>

            <label for="address">Direcció:</label>
            <input type="text" id="address" name="address" value="<?php echo htmlspecialchars($user['direccion']); ?>" required>

            <label for="city">Població:</label>
            <input type="text" id="city" name="city" value="<?php echo htmlspecialchars($user['poblacion']); ?>" required>

            <label for="postalCode">Codi Postal:</label>
            <input type="text" id="postalCode" name="postalCode" value="<?php echo htmlspecialchars($user['codigo_postal']); ?>" required>

            <label for="profilePicture">Imatge de Perfil:</label>
            <input type="file" id="profilePicture" name="profilePicture">

            <label for="currentPassword">Contrasenya Actual:</label>
            <input type="password" id="currentPassword" name="currentPassword">

            <label for="newPassword">Nova Contrasenya:</label>
            <input type="password" id="newPassword" name="newPassword">

            <label for="confirmPassword">Confirma la Nova Contrasenya:</label>
            <input type="password" id="confirmPassword" name="confirmPassword">

            <button type="submit" class="btn">Actualitzar Perfil</button>
        </form>
    </main>

    <?php include 'v_footer.php'; ?>
</body>
</html>
