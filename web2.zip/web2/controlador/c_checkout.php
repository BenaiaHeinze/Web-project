<?php
session_start();
require_once __DIR__ . '/../model/m_cabas.php';
require_once __DIR__ . '/../model/m_checkout.php';

// Ensure the user is logged in
if (!isset($_SESSION['user'])) {
    header('Location: /index.php?accio=login');
    exit;
}

$cart = $_SESSION['cabas'] ?? [];
if (empty($cart)) {
    echo "No hi ha productes al cabàs.";
    exit;
}

$userId = $_SESSION['user']['id'];
$totalItems = 0;
$totalPrice = 0.0;

try {
    foreach ($cart as $productId => $quantity) {
        $product = getProductById($productId);
        $totalItems += $quantity;
        $totalPrice += $product['preu'] * $quantity;
    }

    // Save the order and order lines
    $orderId = saveOrder($userId, $totalItems, $totalPrice);

    foreach ($cart as $productId => $quantity) {
        $product = getProductById($productId);
        $linePrice = $product['preu'] * $quantity;
        saveOrderLine($orderId, $productId, $quantity, $linePrice);
    }

    // Clear the cart
    $_SESSION['cabas'] = [];

    // Redirect to confirmation page
    header('Location: /vistas/v_confirmacio.php?order_id=' . $orderId);
    exit;

} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
    exit;
}
?>
