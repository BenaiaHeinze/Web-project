<?php
require_once '../model/m_user.php';
require_once '../model/connectaDB.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = filter_var($_POST['username'], FILTER_SANITIZE_STRING);
    $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
    $password = $_POST['password']; 
    $address = filter_var($_POST['address'], FILTER_SANITIZE_STRING);
    $city = filter_var($_POST['city'], FILTER_SANITIZE_STRING);
    $postalCode = filter_var($_POST['postalCode'], FILTER_SANITIZE_STRING);

    if (empty($username) || empty($email) || empty($password) || empty($address) || empty($city) || empty($postalCode) || !$username || !$email || !$password || !$address || !$city || !$postalCode) {
        die("Por favor, rellena todos los campos.");
    }

    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

    $connexio = connectaBD();

    if (registerUser($connexio, $username, $email, $hashedPassword, $address, $city, $postalCode)) {
        header('Location: /index.php');
        exit;
    } else {
        header('Location: /index.php?accio=registre');
        exit;
    }
}
?>
