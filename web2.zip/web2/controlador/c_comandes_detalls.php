<?php
session_start();
require_once '../model/m_comandes.php';
require_once '../model/connectaDB.php';

// Ensure the user is logged in
if (!isset($_SESSION['user'])) {
    header('Location: /index.php?accio=login');
    exit;
}

$connexio = connectaBD();
$orderId = $_GET['order_id'] ?? null;

// Validate the order ID
if (!$orderId) {
    echo "No s'ha trobat la comanda.";
    exit;
}

// Fetch the order details and line items
$order = getOrderDetails($connexio, $orderId);
$lineItems = getOrderLineItems($connexio, $orderId);

// Ensure the order belongs to the logged-in user
if (!$order || $order['id_usuari'] != $_SESSION['user']['id']) {
    echo "No tens permís per veure aquesta comanda.";
    exit;
}

// Include the view
include '../vistas/v_comandes_detalls.php';
?>
