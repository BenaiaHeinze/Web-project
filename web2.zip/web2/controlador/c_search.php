<?php
require_once '../model/connectaDB.php';
require_once '../model/m_productes.php';

if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['query'])) {
    $query = filter_var($_GET['query'], FILTER_SANITIZE_STRING);

    // Conexión a la base de datos
    $connexio = connectaBD();

    // Obtiene los productos que coinciden con la búsqueda
    $productos = buscarProductos($connexio, $query);

    pg_close($connexio);

    // Incluye la vista de resultados
    include_once '../vistas/v_search_results.php';
    exit;
} else {
    header('Location: /index.php');
    exit;
}
?>
