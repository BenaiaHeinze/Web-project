<?php
require_once __DIR__.'/../model/connectaDB.php';
require_once __DIR__.'/../model/m_consulta_categories.php';

$connexio = connectaBD();
$categories = consultaCategories($connexio);

include __DIR__.'/../vistas/v_categories.php';

?>
