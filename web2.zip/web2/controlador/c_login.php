<?php
session_start();  // Start a session to store user data after login

require_once '../model/m_user.php';
require_once '../model/connectaDB.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get the email and password from the form
    $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
    $password = $_POST['password']; // The raw password (to be checked later)

    // Connect to the database
    $connexio = connectaBD();

    // Call the model function to authenticate the user
    $user = loginUser($connexio, $email, $password);

    if ($user) {
        $_SESSION['user'] = $user;
        header('Location: /index.php');
    } else {
        header('Location: /index.php?accio=login');
        //$error = "El usuario o la contraseña son incorrectos.";
    }
}

?>