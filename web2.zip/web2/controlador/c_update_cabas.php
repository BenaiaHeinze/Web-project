<?php
session_start();
header('Content-Type: application/json');
require_once '../model/m_cabas.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method.']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);
$action = $data['action'] ?? null;
$id = $data['id'] ?? null;

if (!$id || !isset($_SESSION['cabas'][$id])) {
    echo json_encode(['success' => false, 'message' => 'Product not found in cart.']);
    exit;
}

if ($action === 'update') {
    $quantity = $data['quantity'] ?? null;
    if ($quantity && $quantity > 0) {
        $_SESSION['cabas'][$id] = $quantity;
        $cartSummary = getCartSummary();
        $product = getProductById($id);
        $itemTotal = $product['preu'] * $quantity;

        echo json_encode([
            'success' => true,
            'itemTotal' => $itemTotal,
            'totalPrice' => $cartSummary['totalPrice']
        ]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Invalid quantity.']);
    }
} elseif ($action === 'remove') {
    unset($_SESSION['cabas'][$id]);
    $cartSummary = getCartSummary();

    echo json_encode([
        'success' => true,
        'totalItems' => $cartSummary['totalItems'],
        'totalPrice' => $cartSummary['totalPrice']
    ]);
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid action.']);
}
?>
