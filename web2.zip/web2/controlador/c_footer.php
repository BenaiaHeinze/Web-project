<?php
require_once __DIR__ . '/../vistas/v_footer.php';
?>