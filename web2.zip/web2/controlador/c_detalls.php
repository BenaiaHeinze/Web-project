<?php
require_once __DIR__.'/../model/connectaDB.php';
require_once __DIR__.'/../model/m_consulta_detalls.php';

$connexio = connectaBD();
$id_producte = $_GET['id'];
$producte = consultaProducte($connexio, $id_producte);

include __DIR__.'/../vistas/v_detalls.php';
?>
