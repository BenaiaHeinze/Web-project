<?php
require_once __DIR__ . '/../model/m_cabas.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        if ($_POST['action'] === 'get_cart_summary') {
            $cartSummary = getCartSummary();
            header('Content-Type: application/json');
            echo json_encode([
                'success' => true,
                'totalItems' => $cartSummary['totalItems'],
                'totalPrice' => number_format($cartSummary['totalPrice'], 2),
            ]);
            exit;
        } elseif ($_POST['action'] === 'clear_cart') {
            $success = clearCart();
            header('Content-Type: application/json');
            echo json_encode(['success' => $success]);
            exit;
        }
    }
}

// Si no hay acciones específicas, cargamos la vista del carrito.
$cartSummary = getCartSummary();
$totalPrice = $cartSummary['totalPrice'];
$products = $cartSummary['products'] ?? [];
include __DIR__ . '/../vistas/v_cabas.php';
?>
