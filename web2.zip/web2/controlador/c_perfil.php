<?php
session_start();
require_once '../model/m_user.php';
require_once '../model/connectaDB.php';

// Ensure the user is logged in
if (!isset($_SESSION['user'])) {
    header('Location: /index.php?accio=login');
    exit;
}

$connexio = connectaBD();
$userId = $_SESSION['user']['id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = filter_var($_POST['username'], FILTER_SANITIZE_STRING);
    $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
    $address = filter_var($_POST['address'], FILTER_SANITIZE_STRING);
    $city = filter_var($_POST['city'], FILTER_SANITIZE_STRING);
    $postalCode = filter_var($_POST['postalCode'], FILTER_SANITIZE_STRING);

    $currentPassword = $_POST['currentPassword'] ?? null;
    $newPassword = $_POST['newPassword'] ?? null;
    $confirmPassword = $_POST['confirmPassword'] ?? null;

    $profilePicture = null;
    if (isset($_FILES['profilePicture']) && $_FILES['profilePicture']['error'] === UPLOAD_ERR_OK) {
        $allowedTypes = ['image/jpeg', 'image/png', 'image/jpg'];
        $fileType = mime_content_type($_FILES['profilePicture']['tmp_name']);

        if (!in_array($fileType, $allowedTypes)) {
            header('Location: /vistas/v_perfil.php?error=invalid_file');
            exit;
        }

        $uploadDir = __DIR__ . '/../img/users/';
        $fileName = uniqid() . '_' . basename($_FILES['profilePicture']['name']);
        $filePath = $uploadDir . $fileName;

        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0755, true);
        }

        if (move_uploaded_file($_FILES['profilePicture']['tmp_name'], $filePath)) {
            $profilePicture = $fileName;
        } else {
            header('Location: /vistas/v_perfil.php?error=upload_failed');
            exit;
        }
    }

    if ($newPassword || $confirmPassword) {
        if ($newPassword !== $confirmPassword) {
            header('Location: /vistas/v_perfil.php?error=password_mismatch');
            exit;
        } elseif (!password_verify($currentPassword, $_SESSION['user']['contrasenya'])) {
            header('Location: /vistas/v_perfil.php?error=incorrect_password');
            exit;
        } else {
            $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
            $passwordUpdated = updatePassword($connexio, $userId, $hashedPassword);

            if (!$passwordUpdated) {
                header('Location: /vistas/v_perfil.php?error=password_update_failed');
                exit;
            }
        }
    }

    $success = updateUser($connexio, $userId, $username, $email, $address, $city, $postalCode, $profilePicture);

    if ($success) {
        $_SESSION['user'] = getUserById($connexio, $userId);
        header('Location: /vistas/v_perfil.php?success=1');
        exit;
    } else {
        header('Location: /vistas/v_perfil.php?error=update_failed');
        exit;
    }
}

$user = getUserById($connexio, $userId);

include '../vistas/v_perfil.php';
?>
