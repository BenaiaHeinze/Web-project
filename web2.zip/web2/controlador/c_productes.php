<?php
require_once __DIR__.'/../model/connectaDB.php';
require_once __DIR__.'/../model/m_consulta_productes.php';

$connexio = connectaBD();
$id_categoria = $_GET['id'];
$llibres = consultaProductes($connexio, $id_categoria);

include __DIR__.'/../vistas/v_productes.php';
?>
