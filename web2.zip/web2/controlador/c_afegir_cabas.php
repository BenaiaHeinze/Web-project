<?php
require_once __DIR__ . '/../model/m_cabas.php';

header('Content-Type: application/json');

// Start the session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Decode JSON input
$input = json_decode(file_get_contents('php://input'), true);

// Validate input
$id_producte = $input['id'] ?? null;
$quantitat = $input['quantitat'] ?? null;

if (is_numeric($id_producte) && is_numeric($quantitat) && $quantitat > 0) {
    $success = afegirAlCabas($id_producte, $quantitat);

    if ($success) {
        $cartSummary = getCartSummary();
        $product = getProductById($id_producte); // Obtenim el producte
        echo json_encode([
            'success' => true,
            'message' => 'Producte afegit al cabàs correctament.',
            'summary' => $cartSummary,
            'product' => [
                'id' => $id_producte,
                'nom' => $product['nom'],
                'quantitat' => $quantitat,
                'preu' => $product['preu']
            ]
        ]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Error en afegir el producte al cabàs.']);
    }
}

?>
