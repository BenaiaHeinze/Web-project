<?php
session_start();
require_once __DIR__.'/../model/connectaDB.php';
require_once __DIR__.'/../model/m_comandes.php';


// Ensure the user is logged in
if (!isset($_SESSION['user'])) {
    header('Location: /index.php?accio=login');
    exit;
}

$connexio = connectaBD();
$userId = $_SESSION['user']['id'];

// Get all orders for the logged-in user
$orders = getUserOrders($connexio, $userId);
if (!$orders) {
    $orders = []; // Asegúrate de que sea un array vacío si no hay resultados.
}
// Include the view
require_once __DIR__.'/../vistas/v_comandes.php';
?>
