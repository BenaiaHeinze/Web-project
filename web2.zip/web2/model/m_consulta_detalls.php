<?php
function consultaProducte($connexio, $id_producte){
    $sql_producte = "SELECT nom, preu, autor, isbn, descripcio, path_img FROM producte WHERE id = $1";
    $consulta_producte = pg_query_params($connexio, $sql_producte, array($id_producte)) or die("Error sql producte");
    $resultat_producte = pg_fetch_assoc($consulta_producte);
    return($resultat_producte);
}
?>
