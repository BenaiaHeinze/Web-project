<?php
function registerUser($connexio, $username, $email, $password, $adress, $city, $postalCode) {
    $sql = "INSERT INTO usuari (nom, email, contrasenya, direccion, poblacion, codigo_postal) VALUES ($1, $2, $3, $4, $5, $6)";
    $result = pg_query_params($connexio, $sql, array($username, $email, $password, $adress, $city, $postalCode));
    return $result ? true : false;
}

function loginUser($connexio, $email, $password) {
    // Query to find the user by email
    $sql = "SELECT * FROM usuari WHERE email = $1";
    $result = pg_query_params($connexio, $sql, array($email));

    if ($result && pg_num_rows($result) > 0) {
        // Fetch the user data
        $user = pg_fetch_assoc($result);

        // Verify the password
        if (password_verify($password, $user['contrasenya'])) {
            // Password matches, return the user data (exclude the password)
            unset($user['contrasenya']); // Don't return the password
            return $user;  // Return user data if authentication is successful
        }
    }
    return false;
}

function getUserById($connexio, $userId) {
    $query = "SELECT * FROM usuari WHERE id = $1";
    $result = pg_query_params($connexio, $query, [$userId]);

    return $result ? pg_fetch_assoc($result) : null;
}

function updateUser($connexio, $userId, $username, $email, $address, $city, $postalCode, $profilePicture = null) {
    if ($profilePicture) {
        $query = "UPDATE usuari SET nom = $1, email = $2, direccion = $3, poblacion = $4, codigo_postal = $5, path_img = $6 WHERE id = $7";
        $params = [$username, $email, $address, $city, $postalCode, $profilePicture, $userId];
    } else {
        $query = "UPDATE usuari SET nom = $1, email = $2, direccion = $3, poblacion = $4, codigo_postal = $5 WHERE id = $6";
        $params = [$username, $email, $address, $city, $postalCode, $userId];
    }

    $result = pg_query_params($connexio, $query, $params);
    return $result ? true : false;
}

function updatePassword($connexio, $userId, $hashedPassword) {
    $query = "UPDATE usuari SET contrasenya = $1 WHERE id = $2";
    $result = pg_query_params($connexio, $query, [$hashedPassword, $userId]);
    return $result ? true : false;
}


?>
