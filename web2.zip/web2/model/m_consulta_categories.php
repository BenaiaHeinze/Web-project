<?php
function consultaCategories($connexio){
    $sql_categories = "SELECT id, nom, path_img FROM categoria";
    $consulta_categories = pg_query($connexio, $sql_categories) or die("Error sql categories");
    $resultat_categories = pg_fetch_all($consulta_categories);
    return($resultat_categories);
}
?>
