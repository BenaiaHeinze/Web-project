<?php
// Function to get all orders for a specific user
function getUserOrders($connexio, $userId) {
    $query = "SELECT id, num_elements, data_creació, import_total 
              FROM comanda 
              WHERE id_usuari = $1 
              ORDER BY data_creació DESC";
    $result = pg_query_params($connexio, $query, [$userId]);

    if ($result) {
        return pg_fetch_all($result);
    }

    return [];
}

// Function to get order details by order ID
function getOrderDetails($connexio, $orderId) {
    $query = "SELECT * FROM comanda WHERE id = $1";
    $result = pg_query_params($connexio, $query, [$orderId]);

    return $result ? pg_fetch_assoc($result) : null;
}

// Function to get line items for a specific order
function getOrderLineItems($connexio, $orderId) {
    $query = "SELECT lc.num_producte, lc.preu_total, p.nom 
              FROM linia_comanda lc 
              JOIN producte p ON lc.id_producte = p.id 
              WHERE lc.id_comanda = $1";
    $result = pg_query_params($connexio, $query, [$orderId]);

    return $result ? pg_fetch_all($result) : [];
}

?>
