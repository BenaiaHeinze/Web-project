<?php
function buscarProductos($connexio, $query) {
    // Filtrar productos solo por el nombre
    $sql = "SELECT id, nom, descripcio, preu, path_img FROM producte WHERE nom ILIKE $1";
    $result = pg_query_params($connexio, $sql, array('%' . $query . '%'));
    $productos = [];
    if ($result) {
        while ($row = pg_fetch_assoc($result)) {
            $productos[] = $row;
        }
    }
    return $productos;
}
?>
