<?php
function afegirAlCabas($id_producte, $quantitat) {
    if (session_status() == PHP_SESSION_NONE) {
        session_start();
    }
    

    if (!isset($_SESSION['cabas'])) {
        $_SESSION['cabas'] = [];
    }

    if (isset($_SESSION['cabas'][$id_producte])) {
        $_SESSION['cabas'][$id_producte] += $quantitat;
    } else {
        $_SESSION['cabas'][$id_producte] = $quantitat;
    }

    return true;
}

function getCartSummary() {
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }

    if (!isset($_SESSION['cabas']) || empty($_SESSION['cabas'])) {
        return ['totalItems' => 0, 'totalPrice' => 0.00, 'products' => []];
    }

    require_once __DIR__ . '/connectaDB.php';
    $connexio = connectaBD();

    $totalItems = 0;
    $totalPrice = 0.00;
    $products = [];

    foreach ($_SESSION['cabas'] as $id => $quantity) {
        $query = "SELECT id, nom, preu, path_img FROM producte WHERE id = $1";
        $result = pg_query_params($connexio, $query, [$id]);

        if ($result && pg_num_rows($result) > 0) {
            $product = pg_fetch_assoc($result);
            $product['quantitat'] = $quantity;
            $product['itemTotal'] = $quantity * $product['preu'];
            $totalItems += $quantity;
            $totalPrice += $product['itemTotal'];
            $products[] = $product;
        }
    }

    return [
        'totalItems' => $totalItems,
        'totalPrice' => $totalPrice,
        'products' => $products,
    ];
}




function getProductById($id) {
    require_once __DIR__ . '/connectaDB.php';

    $connexio = connectaBD();
    $sql = "SELECT id, nom, preu, path_img FROM producte WHERE id = $1";
    $result = pg_query_params($connexio, $sql, array($id));

    if ($result && pg_num_rows($result) > 0) {
        return pg_fetch_assoc($result);
    }

    return null; // Return null if product not found
}

function clearCart() {
    if (session_status() == PHP_SESSION_NONE) {
        session_start();
    }
    $_SESSION['cabas'] = [];
    return true;
}

?>


