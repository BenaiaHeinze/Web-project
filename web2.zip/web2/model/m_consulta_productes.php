<?php
function consultaProductes($connexio, $categoria){
    $sql_productes = "SELECT id, nom, autor, path_img FROM producte WHERE id_categoria = $1";
    $consulta_productes = pg_query_params($connexio, $sql_productes, array($categoria)) or die("Error sql productes");
    $resultat_productes = pg_fetch_all($consulta_productes);
    return($resultat_productes);
}
?>
