<?php
function connectaBD(){
    $servidor = "localhost";
    $port = "5432";
    $DBnom = "tdiw-e2";
    $usuari = "tdiw-e2";
    $clau = "videojuego";
    $connexio = pg_connect("host=$servidor port=$port dbname=$DBnom user=$usuari password=$clau") or die("Error connexio DB");
    return($connexio);
}
?>
