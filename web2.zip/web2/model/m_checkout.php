<?php
require_once __DIR__ . '/../model/connectaDB.php';

function saveOrder($userId, $numItems, $totalPrice) {
    $connexio = connectaBD();
    $orderDate = date('Y-m-d');

    $query = "INSERT INTO comanda (num_elements, data_creació, import_total, id_usuari) 
              VALUES ($1, $2, $3, $4) RETURNING id";
    $result = pg_query_params($connexio, $query, [$numItems, $orderDate, $totalPrice, $userId]);

    if (!$result) {
        throw new Exception('Error saving order.');
    }

    return pg_fetch_result($result, 0, 'id');
}

function saveOrderLine($orderId, $productId, $quantity, $linePrice) {
    $connexio = connectaBD();

    $query = "INSERT INTO linia_comanda (num_producte, preu_total, id_comanda, id_producte) 
              VALUES ($1, $2, $3, $4)";
    $result = pg_query_params($connexio, $query, [$quantity, $linePrice, $orderId, $productId]);

    if (!$result) {
        throw new Exception('Error saving order line.');
    }
}

function getOrderDetails($orderId) {
    $connexio = connectaBD();

    $query = "SELECT * FROM comanda WHERE id = $1";
    $result = pg_query_params($connexio, $query, [$orderId]);

    return pg_fetch_assoc($result);
}

function getOrderLineItems($orderId) {
    $connexio = connectaBD();

    $query = "SELECT lc.num_producte, lc.preu_total, p.nom 
              FROM linia_comanda lc 
              JOIN producte p ON lc.id_producte = p.id 
              WHERE lc.id_comanda = $1";
    $result = pg_query_params($connexio, $query, [$orderId]);

    return pg_fetch_all($result);
}
?>
