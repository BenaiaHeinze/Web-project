<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Llibrería Online</title>
        <meta name="description" content="Llibrería Online">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="/../css/formulari.css">
        <script src="/js/jquery-3.3.1.min.js"></script>
        <script src="/js/search.js"></script>
        <script src="/js/validateForm.js"></script>
        <script src="/js/funcions.js"></script>
        
    </head>
    <body>
        <?php include_once __DIR__ . '/../controlador/c_header.php'; ?> <!-- Estructura de cabecera -->
        <?php //include_once __DIR__ . '/../controlador/c_registre.php'; ?>
        
        <main>
            <h2>Registro de Usuario</h2>

            <?php if (isset($_GET['error'])): ?>
                <div class="error-message">
                    <?php 
                    switch ($_GET['error']) {
                        case '1':
                            echo "Por favor, rellena todos los campos.";
                            break;
                        case '2':
                            echo "Datos inválidos. Revisa el formulario.";
                            break;
                        case '3':
                            echo "Error al registrar al usuario. Inténtalo de nuevo.";
                            break;
                        default:
                            echo "Ha ocurrido un error desconocido.";
                    }
                    ?>
                </div>
            <?php endif; ?>
            
            <form action="../controlador/c_registre.php" method="POST" onsubmit="return validateForm()">
                <label for="username">Nombre y apellidos:</label>
                <input type="text" id="username" name="username" required>
                
                <label for="email">Correo electrónico:</label>
                <input type="email" id="email" name="email" required>
                
                <label for="password">Contraseña:</label>
                <input type="password" id="password" name="password" required>

                <label for="address">Dirección:</label>
                <input type="text" id="address" name="address" maxlength="30" required>
                
                <label for="city">Ciudad:</label>
                <input type="text" id="city" name="city" maxlength="30" required>
                
                <label for="postalCode">Código Postal:</label>
                <input type="text" id="postalCode" name="postalCode" required>

                <input type="submit" value="Registrar">
            </form>
        </main>

        <?php require_once __DIR__ . '/../controlador/c_footer.php'; ?> <!-- Estructura de pie de página -->
    </body>
</html>