<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Llibrería Online</title>
    <meta name="description" content="Llibrería Online">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/../css/formulari.css">
    <script src="/js/jquery-3.3.1.min.js"></script>
    <script src="/js/search.js"></script>
    <script src="/js/validateForm.js"></script>
    <script src="/js/funcions.js"></script>

</head>
<body>
    <?php include_once __DIR__. '/../controlador/c_header.php'; ?>

    <main>
        <h2>Iniciar Sesión</h2>

        <?php if (isset($_GET['accio']) && $_GET['accio'] == 'error'): ?>
            <p style="color:red;">Error: Credenciales incorrectas. Intenta de nuevo.</p>
        <?php endif; ?>

        <form action="/../controlador/c_login.php" method="POST">
            <label for="email">Correo Electrónico:</label>
            <input type="email" id="email" name="email" required>

            <label for="password">Contraseña:</label>
            <input type="password" id="password" name="password" required>

            <input type="submit" value="Iniciar Sesión">
        </form>
    </main>

    <?php include __DIR__. '/../controlador/c_footer.php'; ?>
</body>
</html>
