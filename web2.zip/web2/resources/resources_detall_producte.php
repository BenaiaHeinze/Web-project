<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Llibrería Online</title>
        <meta name="description" content="Llibrería Online">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="/../css/llistat.css">
        <script src="/js/jquery-3.3.1.min.js"></script>
        <script src="/js/search.js"></script>
        <script src="/js/validateForm.js"></script>
        <script src="/js/funcions.js"></script>
        
    </head>
    <body>
        <?php include_once __DIR__ . '/../controlador/c_header.php'; ?> <!-- Estructura de cabecera -->

        <div class="content">
            <div id="category-content">
                <?php require_once __DIR__ . '/../controlador/c_detalls.php'; ?> <!-- Controlador que carga las categorías -->
            </div>
        </div>

        <?php require_once __DIR__ . '/../controlador/c_footer.php'; ?> <!-- Estructura de pie de página -->
    </body>
</html>