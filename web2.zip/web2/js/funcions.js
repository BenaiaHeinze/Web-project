$(document).ready(function () {
    /**
     * Actualiza el resumen del carrito en el header.
     */
    function updateCartHeader() {
        fetch('/controlador/c_cabas.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: new URLSearchParams({ action: 'get_cart_summary' })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                $('#cart-total-items').text(data.totalItems);
                $('#cart-total-price').text(parseFloat(data.totalPrice).toFixed(2));
            } else {
                console.error('Error al obtener el resumen del carrito:', data.message);
            }
        })
        .catch(error => console.error('Error al actualizar el carrito en el header:', error));
    }

    /**
     * Añade un producto al carrito.
     */
    function addToCart(productId, quantity) {
        fetch('/controlador/c_afegir_cabas.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id: productId, quantitat: quantity })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                updateCartHeader(); // Actualiza el resumen del carrito en el header.
                $('#cart-response').text(`${data.message}`).css('color', 'green');
            } else {
                $('#cart-response').text(data.message).css('color', 'red');
            }
        })
        .catch(error => {
            console.error('Error al añadir al carrito:', error);
            $('#cart-response').text('Error al añadir al carrito.').css('color', 'red');
        });
    }

    /**
     * Vacía el carrito.
     */
    function clearCart() {
        fetch('/controlador/c_cabas.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: new URLSearchParams({ action: 'clear_cart' })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                updateCartHeader(); // Actualiza el header tras vaciar el carrito.
                location.reload(); // Recarga la página para reflejar los cambios.
            } else {
                console.error('Error al vaciar el carrito:', data.message);
            }
        })
        .catch(error => console.error('Error al vaciar el carrito:', error));
    }

    /**
     * Actualiza la cantidad de un producto en el carrito.
     */
    function updateCartItem(productId, quantity) {
        fetch('/controlador/c_update_cabas.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'update', id: productId, quantity })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                $(`[data-id="${productId}"] .item-total`).text(data.itemTotal.toFixed(2));
                $('#total-price').text(data.totalPrice.toFixed(2));
                updateCartHeader(); // Actualiza el header tras actualizar la cantidad.
            } else {
                alert(data.message || 'Error al actualizar el producto en el carrito.');
            }
        })
        .catch(error => console.error('Error al actualizar el producto en el carrito:', error));
    }

    /**
     * Elimina un producto del carrito.
     */
    function removeCartItem(productId) {
        fetch('/controlador/c_update_cabas.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'remove', id: productId })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                $(`[data-id="${productId}"]`).remove();
                $('#total-price').text(data.totalPrice.toFixed(2));
                updateCartHeader(); // Actualiza el header tras eliminar un producto.
                if (data.totalItems === 0) {
                    location.reload(); // Recarga la página si el carrito está vacío.
                }
            } else {
                alert(data.message || 'Error al eliminar el producto del carrito.');
            }
        })
        .catch(error => console.error('Error al eliminar el producto del carrito:', error));
    }

    /**
     * Muestra los productos de una categoría y oculta las categorías.
     */
    $(document).on('click', '.category-link', function (e) {
        e.preventDefault();
        const categoryId = $(this).data('id');
        fetch(`/controlador/c_productes.php?id=${categoryId}`)
            .then(response => response.text())
            .then(data => {
                $('#categories').hide(); // Oculta las categorías
                $('#book-detail').hide(); // Oculta detalles de libros
                $('#products').html(data).show(); // Muestra los productos de la categoría seleccionada
            });
    });

    /**
     * Muestra los detalles de un libro y oculta las categorías y productos.
     */
    $(document).on('click', '.book-link', function (e) {
        e.preventDefault();
        const bookId = $(this).data('id');
        fetch(`/controlador/c_detalls.php?id=${bookId}`)
            .then(response => response.text())
            .then(data => {
                $('#categories').hide(); // Oculta las categorías
                $('#products').hide(); // Oculta los productos
                $('#book-detail').html(data).show(); // Muestra los detalles del libro
            });
    });

     // Toggle dropdown for account menu
     $(".account-button").click(function (event) {
        event.preventDefault();
        $(this).next(".dropdown").toggle();
    });

    $(document).click(function (event) {
        if (!$(event.target).closest('.account').length) {
            $(".dropdown").hide();
        }
    });

    /**
     * Configura los eventos para cada acción del carrito.
     */
    function setupCartEvents() {
        // Añadir al carrito
        $(document).on('click', '#add-to-cart', function () {
            const productId = $(this).data('id');
            const quantity = parseInt($('#cantidad').val()) || 1;
            addToCart(productId, quantity);
        });

        // Vaciar el carrito
        $(document).on('click', '#clear-cart-button', function () {
            clearCart();
        });

        // Actualizar cantidad de producto
        $(document).on('change', '.update-quantity', function () {
            const productId = $(this).data('id');
            const quantity = parseInt($(this).val()) || 1;
            updateCartItem(productId, quantity);
        });

        // Eliminar un producto
        $(document).on('click', '.remove-item', function () {
            const productId = $(this).data('id');
            removeCartItem(productId);
        });

        $('#checkout-button').click(function () {
            window.location.href = '/controlador/c_checkout.php';
        });
    
    }

    // Inicializa los eventos y actualiza el carrito al cargar la página.
    setupCartEvents();
    updateCartHeader();
});
