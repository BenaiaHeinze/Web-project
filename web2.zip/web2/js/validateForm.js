function validateForm(event) {
    const username = document.getElementById("username");
    const email = document.getElementById("email");
    const address = document.getElementById("address");
    const city = document.getElementById("city");
    const postalCode = document.getElementById("postalCode");
    const currentPassword = document.getElementById("currentPassword");
    const newPassword = document.getElementById("newPassword");
    const confirmPassword = document.getElementById("confirmPassword");

    let isValid = true;

    const clearError = (element) => {
        const errorSpan = element.nextElementSibling;
        if (errorSpan && errorSpan.classList.contains("error-message")) {
            errorSpan.remove();
        }
    };

    const showError = (element, message) => {
        clearError(element);
        const errorSpan = document.createElement("span");
        errorSpan.className = "error-message";
        errorSpan.style.color = "red";
        errorSpan.textContent = message;
        element.parentNode.insertBefore(errorSpan, element.nextSibling);
        isValid = false;
    };

    // Validation rules
    clearError(username);
    if (!/^[a-zA-Z\s]{3,30}$/.test(username.value)) {
        showError(username, "Nom ha de tenir entre 3 i 30 caràcters.");
    }

    clearError(email);
    if (!/^[\w.-]+@[\w.-]+\.\w{2,4}$/.test(email.value)) {
        showError(email, "Correu electrònic invàlid.");
    }

    clearError(address);
    if (address.value.length < 5) {
        showError(address, "Adreça ha de tenir almenys 5 caràcters.");
    }

    clearError(city);
    if (!/^[a-zA-Z\s]+$/.test(city.value)) {
        showError(city, "Població només pot contenir lletres.");
    }

    clearError(postalCode);
    if (!/^\d{5}$/.test(postalCode.value)) {
        showError(postalCode, "Codi Postal ha de tenir 5 dígits numèrics.");
    }

    // Password validation
    if (newPassword.value || confirmPassword.value) {
        clearError(newPassword);
        if (!/(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}/.test(newPassword.value)) {
            showError(newPassword, "La nova contrasenya ha de tenir majúscules, minúscules, números i caràcters especials.");
        }

        clearError(confirmPassword);
        if (newPassword.value !== confirmPassword.value) {
            showError(confirmPassword, "La confirmació de la contrasenya no coincideix.");
        }
    }

    if (!isValid) {
        event.preventDefault(); // Prevent form submission
    }
}

document.addEventListener("DOMContentLoaded", () => {
    const form = document.getElementById("editProfileForm");
    if (form) {
        form.addEventListener("submit", validateForm);
    }
});
