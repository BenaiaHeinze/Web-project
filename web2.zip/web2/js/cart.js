document.addEventListener("DOMContentLoaded", () => {
    // Función para actualizar el resumen del carrito
    function updateCartSummary() {
        fetch('/controlador/c_cart_summary.php')
            .then(response => {
                if (!response.ok) {
                    throw new Error("Error al obtener el resumen del carrito.");
                }
                return response.json();
            })
            .then(data => {
                // Actualiza los valores en el header
                document.getElementById("cart-total-items").textContent = data.totalItems;
                document.getElementById("cart-total-price").textContent = data.totalPrice;
            })
            .catch(error => console.error("Error actualizando el carrito:", error));
    }

    // Llama a la función para actualizar el carrito al cargar la página
    updateCartSummary();

    // Intercepta el botón "Añadir al carrito"
    document.addEventListener("click", (event) => {
        if (event.target && event.target.id === "add-to-cart") {
            const productId = event.target.dataset.id; // Obtén el ID del producto
            const quantity = parseInt(document.getElementById("cantidad").value) || 1;

            fetch('/controlador/c_afegir_cabas.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ id: productId, quantitat: quantity })
            })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        updateCartSummary(); // Actualiza el resumen del carrito
                    } else {
                        console.error("Error al añadir al carrito:", data.message);
                    }
                })
                .catch(error => console.error("Error al añadir al carrito:", error));
        }
    });
});
