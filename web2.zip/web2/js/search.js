document.addEventListener('DOMContentLoaded', () => {
    const searchBar = document.getElementById('search-bar');
    const searchResults = document.getElementById('search-results');

    searchBar.addEventListener('input', async (event) => {
        const query = event.target.value.trim();

        if (query.length < 2) {
            searchResults.style.display = 'none';
            return;
        }

        try {
            const response = await fetch(`/controlador/c_search.php?query=${encodeURIComponent(query)}`);
            const productos = await response.json();

            if (productos.length > 0) {
                searchResults.style.display = 'block';
                searchResults.innerHTML = productos.map(producto => `
                    <div class="search-item">
                        <img src="${producto.path_img}" alt="${producto.nom}" />
                        <div>
                            <strong>${producto.nom}</strong>
                            <p>${producto.descripcio}</p>
                            <span>€${producto.preu}</span>
                        </div>
                    </div>
                `).join('');
            } else {
                searchResults.style.display = 'block';
                searchResults.innerHTML = '<p>No se encontraron resultados.</p>';
            }
        } catch (error) {
            console.error('Error al buscar productos:', error);
        }
    });
});
